<?php /* Template Name: Homepage */
get_header();
?>
<?php
$main_heading = get_field( "main_heading" );
$bann_heading2 = get_field( "bann_heading2" );
$bann_heading3 = get_field( "bann_heading3" );
$sub_heading = get_field( "sub_heading" );
$text = get_field( "text" );
$cta1 = get_field( "cta1" );
$cta2 = get_field( "cta2" );
$bann_img = get_field( "banner_image" );
$bann_gif = get_field( "banner_gif" );
?>
<section class="banner">
   <div class="slider-info">
      <video src="<?php bloginfo('template_directory'); ?>/assets/img/video.mp4" loop muted autoplay></video>
      <div class="container">
         <div class="row align-items-center">
            <div class="col-md-6 col-lg-7">
               <div class="slider-Content">
                  <h1 class="wow fadeInUp">
                     Bringing back<br /> <span>quality to Arizona</span>
                  </h1>
                  <!-- <h6 class="wow fadeInUp">Coming to a location near you – August 2024</h6> -->
                  <p class="wow fadeInUp">Zonacated has always been dedicated and known for our recognizable commitment to providing the best quality. We are here to represent the other side and to bring back the real craft flower. </p>
                  <div class="slider-Content-btn wow fadeInUp">
                     <a href="#" class="red-btn">Read more</a>
                     <a href="#" class="border-white-btn">Contact us</a>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </div>
</section>
<?php get_footer(); ?>