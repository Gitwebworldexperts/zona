<?php

add_theme_support('custom-logo');
add_theme_support( 'post-thumbnails' );
add_theme_support('menus');
register_nav_menus(
    array(
        'primary-menu'=>'Header Menu',
        'footer-menu' => 'Footer Links',
        'mobile-menu'=> 'Mobile Menu'
    )
);



function add_menu_classes_custom($classes, $item, $args) {
    if ($args->theme_location == 'primary-menu') {
    $classes[] = 'nav-item';
    if (in_array('menu-item-has-children', $classes)) {
        $classes[] = 'dropdown';
    }
   }
    return $classes;
}
add_filter('nav_menu_css_class', 'add_menu_classes_custom', 10, 3);


function add_menu_link_attributes_csutom($atts, $item, $args) {
    if ($args->theme_location == 'primary-menu') {
    $atts['class'] = 'nav-link';
}
    return $atts;
}
add_filter('nav_menu_link_attributes', 'add_menu_link_attributes_csutom', 10, 3);

// dropdown

// Acf theme settings
if( function_exists('acf_add_options_page') ) {

    // Register options page.
    $option_page = acf_add_options_page(array(
        'page_title'    => __('Theme Settings'),
        'menu_title'    => __('Theme Settings'),
        'menu_slug'     => 'theme-general-settings',
        'capability'    => 'edit_posts',
        'redirect'      => false
    ));
}


// Register Custom Post Type
function custom_product_and_post_type() {
    $labels = array(
        'name'                  => 'Products & Strains', 
        'singular_name'         => 'Products & Strains', 
        'menu_name'             => 'Products',
        'name_admin_bar'        => 'Products & Strains',
        'all_items'             => 'Products & Strains',
        'add_new_item'          => 'Add New Product',
        'add_new'               => 'Add New',
        'new_item'              => 'New Product',
        'edit_item'             => 'Edit Product',
        'update_item'           => 'Update Product', 
        'view_item'             => 'View Product',
        'view_items'            => 'View Product',
        'search_items'          => 'Search Product',
        'not_found'             => 'Not found',
        'not_found_in_trash'    => 'Not found in Trash'
    );
    $args = array(
        'labels'                => $labels,
        'rewrite'               => array('slug' => 'products-strains'),
        'supports'              => array( 'title', 'editor', 'thumbnail', 'excerpt', 'custom-fields' ),
        'taxonomies'            => array('category', 'post_tag'), // Corrected taxonomies
        'hierarchical'          => true,
        'public'                => true,
        'show_in_admin_bar'     => true,
        'show_in_nav_menus'     => true,
    );
    register_post_type( 'products_strains', $args );
}
add_action( 'init', 'custom_product_and_post_type', 0 );


?>